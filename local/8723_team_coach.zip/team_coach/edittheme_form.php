<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Run the code checker from the web.
 *
 * @package    local_team_coach
 * @copyright  2011 The Open University
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir . '/formslib.php');

class enrol_attributes_edit_form extends moodleform {
    // Add elements to form
    public function definition() {
        global $DB,$USER,$CFG;
        $mform = $this->_form;
        $editoroptions = $this->_customdata['editoroptions'];
        list($instance) = $this->_customdata;        
        $mform->addElement('header', 'header', 'Theme Setting');
        $mform->addElement('hidden', 'themeid', $id);

        $mform->addElement('text', 'url', get_string('url','local_team_coach')); 
        $mform->addRule('url', get_string('required'), 'required', null, 'server');

        $mform->addElement('text', 'name', get_string('name','local_team_coach')); 
        $mform->addRule('name', get_string('required'), 'required', null, 'server');
        // $mform->addRule('name', get_string('required'), 'lettersonly', null, 'server');
        
        $mform->addElement('filemanager', 'logo_filemanager', "Badge Image",null, $editoroptions);
        $mform->addRule('logo_filemanager', get_string('required'), 'required', null, 'client');

        $mform->addElement('text', 'theme_color', get_string('theme_color','local_team_coach')); 
        $mform->addRule('theme_color', get_string('required'), 'required', null, 'server');
        $langs = get_string_manager()->get_list_of_translations();
        $options = array(                                                                                                           
            'multiple' => true,                                                  
            'noselectionstring' => 'Select Language',                                                                
        );         
        $mform->addElement('autocomplete', 'lang', get_string('preferredlanguage'), $langs, $options);
        $mform->addRule('lang', get_string('required'), 'required', null, 'client');
        

        //$purpose = user_edit_map_field_purpose($USER->id, 'lang');
        //$translations = get_string_manager()->get_list_of_translations();
       // $select = $mform->addElement('select', 'lang', get_string('preferredlanguage'), $translations, $purpose);
        //$lang = empty($USER->lang) ? $CFG->lang : $USER->lang;
        //$mform->setDefault('lang', $lang);
        //$mform->addRule('lang', get_string('required'), 'required', null, 'server');
        //$select->setMultiple(true);
       // $select->setSelected(array('val1', 'val2'));
        $mform->addElement('select', 'signup', get_string('login_signup','local_team_coach'),[''=>'Select','1'=>'Enable','2'=>'Disable']); 
        $mform->addRule('signup', get_string('required'), 'required', null, 'server');
        $mform->addElement('hidden', 'id');
        $mform->setType('id', PARAM_INT);       
        $this->add_action_buttons();     
        $this->set_data($instance);    
    }
    // Custom validation should be added here.
    function validation($data, $files) {
        global $CFG, $DB, $USER;

        $validated = array();
        $data = (object)$data;
        $data->name = trim($data->name);
        /*$url_column = $DB->sql_compare_text('url');
        if (!$data->themeid) {
            if ($DB->record_exists('theme_detail', array('name' => $data->name, 'userid' => $USER->id))) {
                $validated['name'] = get_string('nameexists','local_team_coach');
            }
            if ($DB->record_exists('theme_detail', array($url_column => $data->url, 'userid' => $USER->id))) {
                $validated['url'] = get_string('urlexists','local_team_coach');
            }
        }
        else {
            if (!$DB->record_exists('theme_detail', array('name' => $data->name, 'userid' => $USER->id, 'id'=> $data->themeid))) {
                if ($DB->record_exists('theme_detail', array('name' => $data->name, 'userid' => $USER->id))) {
                    $validated['name'] = get_string('nameexists','local_team_coach');
                }
            }

            if (!$DB->record_exists('theme_detail', array($url_column => $data->url, 'userid' => $USER->id, 'id'=> $data->themeid))) {
                if ($DB->record_exists('theme_detail', array($url_column => $data->url, 'userid' => $USER->id))) {
                    $validated['url'] = get_string('urlexists','local_team_coach');
                }
            }
        }*/
        return $validated;
    }
}
