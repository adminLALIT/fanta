<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * A two column layout for the boost theme.
 *
 * @package   theme_boost
 * @copyright 2016 Damyon Wiese
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

global $DB,$COURSE,$PAGE,$OUTPUT,$USER;
user_preference_allow_ajax_update('drawer-open-nav', PARAM_ALPHA);
require_once($CFG->libdir . '/behat/lib.php');
use theme_boost\util\theme_settings;
$themesettings = new \theme_boost\util\theme_settings();

if (isloggedin()) {
    $navdraweropen = (get_user_preferences('drawer-open-nav', 'true') == 'true');
} else {
    $navdraweropen = false;
}
$extraclasses = [];
if ($navdraweropen) {
    $extraclasses[] = 'drawer-open-left';
}
$bodyattributes = $OUTPUT->body_attributes($extraclasses);
$blockshtml = $OUTPUT->blocks('side-pre');
$hasblocks = strpos($blockshtml, 'data-block=') !== false;
$buildregionmainsettings = !$PAGE->include_region_main_settings_in_header_actions();
// If the settings menu will be included in the header then don't add it here.
$regionmainsettingsmenu = $buildregionmainsettings ? $OUTPUT->region_main_settings_menu() : false;

$theme = theme_config::load('boost');
$templatecontext['sliderenabled'] = $theme->settings->sliderenabled;
if (empty($templatecontext['sliderenabled'])) {
    $templatecontext= '';

}
else{
    $slidercount = $theme->settings->slidercount;
    for ($i = 1, $j = 0; $i <= $slidercount; $i++, $j++) {
        $sliderimage = "sliderimage{$i}";
        $slidertitle = "slidertitle{$i}";
        $slidercap = "slidercap{$i}";
        $templatecontext_slider['slides'][$j]['key'] = $j;
        $templatecontext_slider['slides'][$j]['active'] = false;
        $image = $theme->setting_file_url($sliderimage, $sliderimage);
        if (empty($image)) {
            $image = $OUTPUT->image_url('slide_default', 'theme');
        }
        $templatecontext_slider['slides'][$j]['image'] = $image;
        $templatecontext_slider['slides'][$j]['title'] = $theme->settings->$slidertitle;
        $templatecontext_slider['slides'][$j]['caption'] = theme_boost_get_setting($slidercap, 'format_html');
        if ($i === 1) {
            $templatecontext_slider['slides'][$j]['active'] = true;
        }
    }
}
// testimonialcount starts 
$testimonialcount = $theme->settings->testimonialcount;
for ($i = 1, $j = 0; $i <= $testimonialcount; $i++, $j++) {
    $testimonialheading = "testimonialheading{$i}";
    $testimonialsubheading = "testimonialsubheading{$i}";
    $testimonialcontent = "testimonialcontent{$i}";
    $testimonial_slider['testimonial'][$j]['key'] = $j;
    
    if($theme->settings->$testimonialcontent != ''){       
      $certificationcapdes=$theme->settings->$testimonialcontent;
    }else{
      $certificationcapdes='No description';
    }
    $testimonial_slider['testimonial'][$j]['testimonialheading'] = theme_boost_get_setting($testimonialheading, 'format_html');
    $testimonial_slider['testimonial'][$j]['testimonialsubheading'] = theme_boost_get_setting($testimonialsubheading, 'format_html');
    $testimonial_slider['testimonial'][$j]['caption'] = theme_boost_get_setting($testimonialcontent, 'format_html');
    if ($i === 1) {
        $testimonial_slider['testimonial'][$j]['active'] = 'active';
    }else{
        $testimonial_slider['testimonial'][$j]['active'] = '';
    }
}
// end
// testimonialcount starts 
$marketingcount = $theme->settings->marketingcount;
for ($i = 1, $j = 0; $i <= $marketingcount; $i++, $j++) {
    $marketingurl = "marketingurl{$i}";
    $marketingheading = "marketingheading{$i}";
    $marketingcontent = "marketingcontent{$i}";
    $marketing_slider['marketing'][$j]['key'] = $j;
    
    if($theme->settings->$marketingcontent != ''){       
      $marketingcapcontent=$theme->settings->$marketingcontent;
    }else{
      $marketingcapcontent='No description';
    }
    
    $marketing_slider['marketing'][$j]['marketingheading'] = theme_boost_get_setting($marketingheading, 'format_html');
    $marketing_slider['marketing'][$j]['marketingurl'] = theme_boost_get_setting($marketingurl, 'format_html');
    $marketing_slider['marketing'][$j]['caption'] = theme_boost_get_setting($marketingcontent, 'format_html');
    if ($i === 1) {
        $marketing_slider['marketing'][$j]['active'] = 'first';
    }else{
        $marketing_slider['marketing'][$j]['active'] = 'middle';
    }
}
// end
$loginurl = $CFG->wwwroot."/login/index.php";
$errormsg = '' ;
$errorcode = optional_param('errorcode', '', PARAM_INT); 

if($errorcode == 1 ){
    $errormsg = get_string("cookiesnotenabled");
}else if($errorcode == 2 ){
    $errormsg = get_string('username').': '.get_string("invalidusername");
}else if($errorcode == 3 ){
    $errormsg = get_string("invalidlogin");
}else if($errorcode == 4 ){
    $errormsg = get_string('sessionerroruser', 'error');
}else if ($errorcode == 5) {
    $errormsg = get_string("unauthorisedlogin", "", $frm->username);
}
else if (!empty($SESSION->loginerrormsg)) {
    // We had some errors before redirect, show them now.
    $errormsg = $SESSION->loginerrormsg;
    unset($SESSION->loginerrormsg);
}
$logourl=$OUTPUT->get_logo_url();
$logouturl = $CFG->wwwroot."/login/forgot_password.php";
$unplaceholder = get_string('unplaceholder', 'theme_boost');

$unfpassword = get_string('unfpassword', 'theme_boost');

$uncaccount = get_string('uncaccount', 'theme_boost');

$logintxttestimonials = get_string('logintxttestimonials', 'theme_boost');

$unlogin = get_string('unlogin', 'theme_boost');
$unpassword = get_string('password');
$coursesearch = get_string('coursesearch');

$go = get_string('go');
$templatecontext = [
    'sitename' => format_string($SITE->shortname, true, ['context' => context_course::instance(SITEID), "escape" => false]),
    'output' => $OUTPUT,
    'sidepreblocks' => $blockshtml,
    'logourl' => $logourl,
    'hasblocks' => $hasblocks,
    'bodyattributes' => $bodyattributes,
    'navdraweropen' => $navdraweropen,
    'errmsg' => $errormsg,
    'bannerslider' => $bannerslider,
    'regionmainsettingsmenu' => $regionmainsettingsmenu,
    'loginurl' => $loginurl,
    'logouturl' => $logouturl,
    'unplaceholder' => $unplaceholder,
    'unpassword' => $unpassword,
    'unfpassword' => $unfpassword,
    'uncaccount' => $uncaccount,
    'unlogin' => $unlogin,
    'fpcoursesearch' => $coursesearch,    
    'fpgo' => $go,
    'logintxttestimonials' => $logintxttestimonials,
    
    'hasregionmainsettingsmenu' => !empty($regionmainsettingsmenu)
];
//print_r($themesettings->testimonial_items());exit;
$templatecontext = array_merge($templatecontext, $templatecontext_slider);
$templatecontext = array_merge($templatecontext, $testimonial_slider);
$templatecontext = array_merge($templatecontext, $marketing_slider);

$templatecontext = array_merge($templatecontext,$themesettings->marketing_items());


$templatecontext = array_merge($templatecontext,$themesettings->testimonial_items());

$nav = $PAGE->flatnav;
$templatecontext['flatnavigation'] = $nav;
$templatecontext['firstcollectionlabel'] = $nav->get_collectionlabel();
echo $OUTPUT->render_from_template('theme_boost/frontpage_team', $templatecontext);
